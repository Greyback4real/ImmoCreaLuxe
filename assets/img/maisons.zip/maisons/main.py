import os

def get_img(path):
    img = []
    for files in os.listdir(path):
        if os.path.isdir(files):
            for f in get_img(path +"/"+ files):
                img.append(f)
        else:
        
            try:
                print(files.split(".")[1])
                if files.split(".")[1] in ['jpg', 'png', 'jpeg']:
                    print(files + " appended")
                    img.append(path + "/" + files)
            except:
                print(f"{files} FAILED")
    print(img)
    return img

print(get_img("./"))